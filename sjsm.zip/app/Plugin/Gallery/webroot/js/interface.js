(function ($) {
    if ($('.swipebox')) {
        $('.swipebox').swipebox();
    }
})(jQuery);
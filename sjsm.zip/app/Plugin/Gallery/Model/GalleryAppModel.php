<?php
/**
 * @var $this View
 */

class GalleryAppModel extends AppModel
{

} 
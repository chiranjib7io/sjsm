Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/multi-select-dropdown-list-with-checkbox-jquery/

============ Instruction ============
=> Open the "index.html" file on the browser and you'll see the example dropdown list with various options.


============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/multi-select-dropdown-list-with-checkbox-jquery/#respond